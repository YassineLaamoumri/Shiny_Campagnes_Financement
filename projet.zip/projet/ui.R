#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)

ui <- dashboardPage(
  dashboardHeader(title = 'Campagnes'),
  dashboardSidebar(sidebarMenu(id = 'MenuTabs',
    menuItem(
      "Graphique1",
      tabName = "Graphique 1",
      icon = icon("chart-line",selected = TRUE)
    ),uiOutput("ui"),
    menuItem(
      "Graphique2",
      tabName = "Graphique 2",
      icon = icon("chart-line")
    )
    
  )),
  dashboardBody(tabItems(
    tabItem(
      tabName = 'Graphique 1',
      box(plotOutput("plot1"), width = 500),
      box(
        selectInput(
          "category",
          'Sélectionné au moins une catégorie',
          choice = data %>% distinct(category),
          multiple = TRUE
        ),
        actionButton("submit", "Appliquer")
        
      )
    )
    
  )
  )
)