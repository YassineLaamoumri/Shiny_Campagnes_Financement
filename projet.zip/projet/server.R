#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(plotly)
library(tidyverse)
# Define server logic required to draw a histogram
shinyServer(function(input, output) {
  data_perimetre <-  data
  data_perimetre <- eventReactive(input$submit, {
    data %>% filter(category %in% input$category)
  }, ignoreNULL = FALSE)   
  
  
  output$plot1 <- renderPlot({
    ## Nombre total nombre total de campagnes
    data_perimetre() %>%  group_by(year_month) %>% summarise(total = n()) %>% ggplot(mapping = aes(x =
                                                                                                   year_month, y = total)) + geom_line() + scale_x_datetime(breaks = '1 month', labels = label_date(format = "%Y-%m-%d")) + theme_minimal() +
      labs(title =
             'Variabilité du nombre de campagnes par mois', x = 'Date', y = 'Nombre de campagnes')
    
    
  })
  
  output$ui <- renderUI({
    return()
    sidebarMenu(id = 'MenuTabs',
                menuItem("Graphique1", tabName = "Graphique2")
    )
  })
  
  
})
